// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Versions // 
/*
*		v1.2.0.0 - 2024-06-03 - Found and documented bug in subtract_numbers template function, added comments to test_underflow template function to explain the bug and how to fix it
*		v1.1.0.0 - 2024-06-03 - Added underflow and overflow tests, error checking in add_numbers and subtract_numbers template functions
*		v1.0.0.0 - 2024-06-03 - Initial version of the NumericOverflows.cpp file
*/

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
//#include <exception>	

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
	T result = start;
	T last_result = result;

	for (unsigned long int i = 0; i < steps; ++i)
	{
		last_result = result;
		result += increment;

		// Check for overflow for all signed types
		if (result < start)
		{
			std::cout << "\t\tOverflow detected! Returning max value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::max();
		}
		// Special cases:
		// Unsigned values
		else if (result < last_result)  // Compare the last result to the current result, if the current result is less than the last result, then we have an overflow
		{
			std::cout << "\t\tOverflow detected! Returning max value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::max();
		}
		// Real numbers
		// Check for floating point values and if the result is infinity, then we have an overflow
		else if (std::is_floating_point<T>::value && std::isinf(result))
		{
			std::cout << "\t\tOverflow detected! Returning max value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::max();
		}

	}

	// Only return the value if it did not overflow, so it is correct
	return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
	T result = start;
	T last_result = result;

	for (unsigned long int i = 0; i < steps; ++i)
	{
		last_result = result;

		// Check for signed types before subtracting, if the result is less than the decrement, then we have an underflow

		if (std::is_signed<T>::value && result < std::numeric_limits<T>::min() + decrement)
		{
			std::cout << "\t\tUnderflow detected! Returning min value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::min();
		}

		// Do the subtraction
		result -= decrement;

		// Check for underflow for wrapping (unsigned) types
		if (result > last_result)  // Compare the last result to the current result, if the current result is greater than the last result, then we have an underflow
		{
			std::cout << "\t\tUnderflow detected! Returning min value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::min();
		}

		// Check for floating point values and if the result is normalized, then we have an underflow
		else if (std::is_floating_point<T>::value && std::fpclassify(result) == FP_SUBNORMAL)
		{
			std::cout << "\t\tUnderflow detected! Returning min value for type " << typeid(T).name() << std::endl;
			return std::numeric_limits<T>::min();
		}

	}


	// Only return the value if it did not underflow, so it is correct
	return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{

	// START DO NOT CHANGE
	//  how many times will we iterate
	const unsigned long int steps = 5;
	// how much will we add each step (result should be: start + (increment * steps))
	const T increment = std::numeric_limits<T>::max() / steps;
	// whats our starting point
	const T start = 0;

	std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
	// END DO NOT CHANGE

	std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
	T result = add_numbers<T>(start, increment, steps);
	std::cout << +result << std::endl;


	std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
	result = add_numbers<T>(start, increment, steps + 1);
	std::cout << +result << std::endl;

	// Due to processing inside the add_numbers method, no changes are needed here

}

template <typename T>
void test_underflow()
{

	// *** This section contains a bug wherein the signed types will not ever actually underflow. 
	// *** This is caused by the start point being the maximum value of the type, 
	// *** and the decrement being a fraction of that maximum value, so the result will become negative, but never 
	// *** underflow. The solution is to change the start point to be 0 or double the number of steps.


	// START DO NOT CHANGE
	//  how many times will we iterate
	const unsigned long int steps = 5;
	// how much will we subtract each step (result should be: start - (increment * steps))
	const T decrement = std::numeric_limits<T>::max() / steps;
	// whats our starting point
	const T start = std::numeric_limits<T>::max();
	//const T start = 0;

	std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
	// END DO NOT CHANGE

	std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
	auto result = subtract_numbers<T>(start, decrement, steps);
	std::cout << +result << std::endl;

	std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
	result = subtract_numbers<T>(start, decrement, steps + 1);
	std::cout << +result << std::endl;

	// Due to processing inside the add_numbers method, no changes are needed here
}

void do_overflow_tests(const std::string& star_line)
{
	std::cout << std::endl << star_line << std::endl;
	std::cout << "*** Running Overflow Tests ***" << std::endl;
	std::cout << star_line << std::endl;

	// Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
	// signed integers
	test_overflow<char>();
	test_overflow<wchar_t>();
	test_overflow<short int>();
	test_overflow<int>();
	test_overflow<long>();
	test_overflow<long long>();

	// unsigned integers
	test_overflow<unsigned char>();
	test_overflow<unsigned short int>();
	test_overflow<unsigned int>();
	test_overflow<unsigned long>();
	test_overflow<unsigned long long>();

	// real numbers
	test_overflow<float>();
	test_overflow<double>();
	test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
	std::cout << std::endl << star_line << std::endl;
	std::cout << "*** Running Undeflow Tests ***" << std::endl;
	std::cout << star_line << std::endl;

	// Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
	// signed integers
	test_underflow<char>();
	test_underflow<wchar_t>();
	test_underflow<short int>();
	test_underflow<int>();
	test_underflow<long>();
	test_underflow<long long>();

	// unsigned integers
	test_underflow<unsigned char>();
	test_underflow<unsigned short int>();
	test_underflow<unsigned int>();
	test_underflow<unsigned long>();
	test_underflow<unsigned long long>();

	// real numbers
	test_underflow<float>();
	test_underflow<double>();
	test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
	//  create a string of "*" to use in the console
	const std::string star_line = std::string(50, '*');

	std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

	// run the overflow tests
	do_overflow_tests(star_line);

	// run the underflow tests
	do_underflow_tests(star_line);

	std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu