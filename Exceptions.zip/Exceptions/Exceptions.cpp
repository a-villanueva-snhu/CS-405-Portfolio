// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>		// Included for custom exception handling

class CustomException : public std::exception
{
private:
	std::string msg_; // Add the non-static data members  

public:
	using std::exception::exception;  // Inherit constructors from std::exception
	CustomException(const std::string& message) : msg_(message) {}  // Our custom exception constructor that takes a message string
	virtual const char* what() const noexcept override { return msg_.c_str(); }  // what() override for std integration
};

bool do_even_more_custom_application_logic()
{
	// Throw a test exception runtime error
	throw CustomException("An error occurred in do_even_more_custom_application_logic.");

	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}

void do_custom_application_logic()
{

	std::cout << "Running Custom Application Logic." << std::endl;

	try
	{
		// If do_even_more_custom_application_logic() exists, call it and check the return value
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Failed." << std::endl;
		}
	}

	// Catch the exception thrown by do_even_more_custom_application_logic() and display a message to the console
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in do_custom_application_logic: " << e.what() << std::endl;
	}

	std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
	// Check for divide by zero and throw an exception if the denominator is zero
	try
	{
		if (den == 0)  // IF denominator is zero, throw an exception to deal with divide by zero errors using a standard C++ defined exception
		{
			throw std::runtime_error("Divide by zero error.");
		}
	}
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in divide: " << e.what() << std::endl;
		return 0; // Return 0 or some other value to indicate an error
	}

	// When we pass the try block without throwing an exception, we can safely perform the division
	return (num / den);
}

void do_division() noexcept
{

	float numerator = 10.0f;
	float denominator = 0;

	// Wrapped the divide function call in a try-catch block to handle any exceptions thrown 
	// by the divide function
	try
	{
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in do_division: " << e.what() << std::endl;
	}
}

int main()
{
	std::cout << "Exceptions Tests!" << std::endl;

	// Division by zero test
	try {
		// Call the function that performs division and handles divide by zero errors
		do_division();
	}
	catch (const CustomException& e)
	{
		std::cout << "Caught runtime_error in main: " << e.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in main: " << e.what() << std::endl;
	}
	catch (...)
	{
		std::cout << "Caught unknown exception in main." << std::endl;

	}

	// Custom application logic test
	try {
		do_custom_application_logic();
	}
	catch (const CustomException& e)
	{
		std::cout << "Caught runtime_error in main: " << e.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in main: " << e.what() << std::endl;
	}
	catch (...)
	{
		std::cout << "Caught unknown exception in main." << std::endl;

	}

	// Even more custom application logic test
	try {
		do_even_more_custom_application_logic();
	}
	catch (const CustomException& e)
	{
		std::cout << "Caught runtime_error in main: " << e.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Caught exception in main: " << e.what() << std::endl;
	}
	catch (...)
	{
		std::cout << "Caught unknown exception in main." << std::endl;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu